from .client import OracleClient

client_class = OracleClient
