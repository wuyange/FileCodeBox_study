from office365.runtime.client_value import ClientValue


class PrinterCapabilities(ClientValue):
    """Represents the capabilities reported by a printer/printerShare."""
