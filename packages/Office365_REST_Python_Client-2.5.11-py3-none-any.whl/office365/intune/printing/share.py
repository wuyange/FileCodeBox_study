from office365.intune.printing.base import PrinterBase


class PrinterShare(PrinterBase):
    """Represents a printer that is intended to be discoverable by users and printing applications."""
