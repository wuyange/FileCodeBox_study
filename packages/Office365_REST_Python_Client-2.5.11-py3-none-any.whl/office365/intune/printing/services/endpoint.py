from office365.entity import Entity


class PrintServiceEndpoint(Entity):
    """Represents URI and identifying information for a print service instance."""
