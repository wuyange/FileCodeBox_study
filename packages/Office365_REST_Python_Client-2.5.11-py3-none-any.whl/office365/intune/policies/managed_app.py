from office365.entity import Entity


class ManagedAppPolicy(Entity):
    """The ManagedAppPolicy resource represents a base type for platform specific policies."""
