from office365.entity import Entity


class ManagedEBook(Entity):
    """An abstract class containing the base properties for Managed eBook."""
