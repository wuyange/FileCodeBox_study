from office365.entity import Entity


class DeviceManagementReports(Entity):
    """Device management reports entity"""
