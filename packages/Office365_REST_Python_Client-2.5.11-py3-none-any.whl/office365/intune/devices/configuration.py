from office365.entity import Entity


class DeviceConfiguration(Entity):
    """Device Configuration."""
