from office365.entity import Entity


class EnrollmentConfigurationAssignment(Entity):
    """Enrollment Configuration Assignment"""
