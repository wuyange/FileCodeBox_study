from office365.entity import Entity


class ServiceAnnouncementBase(Entity):
    """This is an abstract base type for serviceHealthIssue and serviceUpdateMessage."""
