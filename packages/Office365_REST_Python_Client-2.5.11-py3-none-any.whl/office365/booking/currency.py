from office365.entity import Entity


class BookingCurrency(Entity):
    """Represents a monetary currency supported by a bookingBusiness."""
