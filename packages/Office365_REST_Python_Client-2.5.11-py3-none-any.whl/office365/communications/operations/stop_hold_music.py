from office365.communications.operations.comms import CommsOperation


class StopHoldMusicOperation(CommsOperation):
    """
    Represents the status of a stopHoldMusic operation, triggered by a call to the stopHoldMusic API.
    """
