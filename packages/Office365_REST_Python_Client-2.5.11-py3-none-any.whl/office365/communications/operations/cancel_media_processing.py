from office365.communications.operations.comms import CommsOperation


class CancelMediaProcessingOperation(CommsOperation):
    """Describes the response format of the cancel media processing operation."""
