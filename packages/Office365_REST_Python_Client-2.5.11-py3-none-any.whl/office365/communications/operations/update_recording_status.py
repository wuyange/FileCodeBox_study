from office365.communications.operations.comms import CommsOperation


class UpdateRecordingStatusOperation(CommsOperation):
    """Describes the response format of an update recording status action."""
