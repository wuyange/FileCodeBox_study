from office365.communications.operations.comms import CommsOperation


class StartHoldMusicOperation(CommsOperation):
    """
    Represents the status of a startHoldMusic operation, triggered by a call to the startHoldMusic API.
    """
