from office365.entity import Entity


class CallRecording(Entity):
    """Represents a recording associated with an online meeting."""
