from office365.runtime.client_value import ClientValue


class Root(ClientValue):
    """Root container"""
