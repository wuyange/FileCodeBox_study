from office365.runtime.client_value import ClientValue


class PublicErrorDetail(ClientValue):
    """Represents the details of publicError or publicInnerError."""
