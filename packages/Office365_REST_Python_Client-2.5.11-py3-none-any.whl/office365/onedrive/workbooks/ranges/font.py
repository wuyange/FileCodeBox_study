from office365.entity import Entity


class WorkbookRangeFont(Entity):
    """This object represents the font attributes (font name, font size, color, etc.) for an object."""
