from office365.entity import Entity


class WorkbookRangeSort(Entity):
    """Manages sorting operations on Range objects."""
