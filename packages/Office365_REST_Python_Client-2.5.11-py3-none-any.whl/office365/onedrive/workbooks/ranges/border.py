from office365.entity import Entity


class WorkbookRangeBorder(Entity):
    """Represents the border of an object."""
