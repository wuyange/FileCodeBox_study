from office365.entity import Entity


class WorkbookTableSort(Entity):
    """Manages sorting operations on Table objects."""
