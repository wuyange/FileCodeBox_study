from office365.entity import Entity


class Storage(Entity):
    """Facilitates the structures of fileStorageContainers."""
