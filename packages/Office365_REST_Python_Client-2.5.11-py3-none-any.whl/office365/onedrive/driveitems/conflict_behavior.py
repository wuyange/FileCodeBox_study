class ConflictBehavior:
    """"""

    def __init__(self):
        pass

    Rename = "rename"

    Fail = "fail"

    Replace = "replace"
