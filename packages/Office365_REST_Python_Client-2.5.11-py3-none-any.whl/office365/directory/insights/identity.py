from office365.runtime.client_value import ClientValue


class InsightIdentity(ClientValue):
    """Complex type containing properties of sharedInsight items."""
