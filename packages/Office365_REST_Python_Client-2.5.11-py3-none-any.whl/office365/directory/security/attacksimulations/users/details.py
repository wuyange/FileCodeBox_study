from office365.runtime.client_value import ClientValue


class UserSimulationDetails(ClientValue):
    """Represents a user of a tenant and their online actions in an attack simulation and training campaign."""
