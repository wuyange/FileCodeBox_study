from office365.runtime.client_value import ClientValue


class SynchronizationJobRestartCriteria(ClientValue):
    """Defines the scope of the synchronizationJob: restart action."""
