from office365.entity import Entity


class AuthenticationStrengthRoot(Entity):
    """The authenticationStrengthRoot resource is the entry point for the authentication strengths object model."""
