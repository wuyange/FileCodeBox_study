from office365.entity import Entity


class AuthenticationMethodModeDetail(Entity):
    """
    The details of the authenticationMethodModes objects that can be defined for the allowedCombinations property
    of the authenticationstrengthpolicy.
    """
