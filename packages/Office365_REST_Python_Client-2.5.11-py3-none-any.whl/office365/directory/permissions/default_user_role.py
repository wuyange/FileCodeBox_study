from office365.runtime.client_value import ClientValue


class DefaultUserRolePermissions(ClientValue):
    """Contains certain customizable permissions of default user role in Microsoft Entra ID."""
