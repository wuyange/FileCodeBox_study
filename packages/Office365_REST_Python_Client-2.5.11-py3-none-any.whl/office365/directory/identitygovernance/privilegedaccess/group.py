from office365.entity import Entity


class PrivilegedAccessGroup(Entity):
    """The entry point for all resources related to Privileged Identity Management (PIM) for groups."""
